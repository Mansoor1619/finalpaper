/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Bunny
 */
abstract class Observer {
    
    public abstract void Admin();
    public abstract void DetailStart();
    public abstract void Faculty();
    public abstract void Remove();
    public abstract void Student();
    public abstract void Update();
    public abstract void View();
    
}
