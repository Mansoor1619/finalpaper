/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Bunny
 */
public class StudentTest {
    
    public StudentTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

     String Ename="mansoor";
    String Ephone="negative";
    String Ecovidtest="123";
   
    @Test
    public void TestMain()
    {
        
        System.out.println("Recieving ");
        
        
        try {
     java.sql.Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/emp", "root", "");

     PreparedStatement st = connection.prepareStatement("INSERT into employee (name, phone, covidtest) VALUES ('"+Ename+"','"+Ephone+"','"+Ecovidtest+"')");

     ResultSet rs = st.executeQuery();
     if (rs.next()) {
         System.out.println(rs.getString("name"));
         assertEquals(Ephone, rs.getString("name"));
     } else {
         System.out.println("NO ENTRIES");
     }
     } catch (SQLException sqlException) {
 }

}
    
}
